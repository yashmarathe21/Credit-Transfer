<?php 
	$con = mysqli_connect("localhost","id9568797_abc","root123","id9568797_credit_transfer") or die("Connection was not established");
 ?>