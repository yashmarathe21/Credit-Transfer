<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>The Sparks Foundation</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/transfer.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">The Sparks Foundation</span> <br> Credit Management <br> <br></h1>
        </div>
        <nav>
          <ul>
            <li><a href="home.php"><strong>Home</strong></a></li>
            <li><a href="users.php"><strong>Click here to view all Users</strong></a></li>
          </ul>
        </nav>
      </div>
    </header>