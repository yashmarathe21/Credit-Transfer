<footer>
      <p>The Sparks Foundation, Copyright &copy; 2019</p>
</footer>